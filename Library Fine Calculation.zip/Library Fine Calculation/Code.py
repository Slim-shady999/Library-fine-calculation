from datetime import datetime

def calculate_fine(book_id, due_date, return_date):
    due_date = datetime.strptime(due_date, '%Y-%m-%d')
    return_date = datetime.strptime(return_date, '%Y-%m-%d')
    days_overdue = (return_date - due_date).days
    fine_rate = 0
    fine_amount = 0

    if days_overdue <= 7:
        fine_rate = 20
    elif days_overdue <= 14:
        fine_rate = 50
    else:
        fine_rate = 100

    fine_amount = fine_rate * days_overdue

    print("Book ID:", book_id)
    print("Due Date:", due_date.strftime('%Y-%m-%d'))
    print("Return Date:", return_date.strftime('%Y-%m-%d'))
    print("Days Overdue:", days_overdue)
    print("Fine Rate:", fine_rate)
    print("Fine Amount:", fine_amount)


# Get input from the user
book_id = input("Enter the Book ID: ")
due_date = input("Enter the Due Date (YYYY-MM-DD): ")
return_date = input("Enter the Return Date (YYYY-MM-DD): ")

# Call the function to calculate the fine
calculate_fine(book_id, due_date, return_date)